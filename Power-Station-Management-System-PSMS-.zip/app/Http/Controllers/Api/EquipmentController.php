<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Equipment;
use Illuminate\Http\Request;
use App\Http\Requests\Equipment\StoreEquipmentRequest;
use App\Http\Requests\Equipment\UpdateEquipmentRequest;
use App\Http\Requests\Equipment\DescribeEquipmentRequest;
use App\Http\Resources\Equipment\EquipmentResource;
use App\Traits\ApiResponse;

class EquipmentController extends Controller
{
    use ApiResponse;

    public function myStats(Request $request)
    {
        $userId = $request->user()->id;

        $totalEquipment = Equipment::where('user_id', $userId)->count();

        $byStatus = Equipment::where('user_id', $userId)
            ->selectRaw('status, count(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        return $this->success('تم جلب إحصائيات المهندس بنجاح.', [
            'total_equipment' => $totalEquipment,
            'by_status' => $byStatus,
        ]);
    }
    public function stats()
    {
        $totalEquipment = Equipment::count();

        $byStatus = Equipment::query()
            ->selectRaw('status, COUNT(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        return $this->success(
            'تم جلب إحصائيات المعدات بنجاح.',
            [
                'total_equipment' => $totalEquipment,
                'by_status' => $byStatus,
            ]
        );
    }

    // Get all equipment
    // use the EquipmentResource to format the response
    // use the with() method to eager load the related models
    public function index(Request $request)
    {
        $this->authorize('viewAny', Equipment::class);

        $user = $request->user();

        $query = Equipment::with(['user', 'creator']);

        // فلترة على مستوى السجل حسب الدور (الأدمن يشوف كل المعدات،
        // Gate::before يتجاوز الشرط أصلاً، بس نحطه هنا لأنه فلترة استعلام مو Policy)
        if (! $user->hasRole('admin')) {
            // المهندس والقارئ: بس المعدات المرتبطة فيهم (user_id)
            $query->where('user_id', $user->id);
        }

        // بحث باسم المعدة أو رقمها التسلسلي
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('equipment_name', 'like', "%{$search}%")
                    ->orWhere('serial_number', 'like', "%{$search}%");
            });
        }

        // فلترة حسب الحالة
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $equipment = $query->latest()->paginate(10);

        return $this->success('تم جلب المعدات بنجاح.', $equipment);
    }

    // Store a newly created equipment in storage.
    public function store(StoreEquipmentRequest $request)
    {
        $data = $request->validated();

        $equipment = Equipment::create($data);

        $equipment->load([
            'user',
            'creator',
        ]);

        return $this->success(
            'Equipment created successfully.',
            new EquipmentResource($equipment),
            201
        );
    }

    // Display the specified equipment.
    public function show(Equipment $equipment)
    {
        $this->authorize('view', $equipment);

        $equipment->load([
            'user',
            'creator',
        ]);

        return $this->success(
            'Equipment retrieved successfully.',
            new EquipmentResource($equipment)
        );
    }

    // Update the specified equipment in storage.
    public function update(
        UpdateEquipmentRequest $request,
        Equipment $equipment
    ) {
        $this->authorize('update', $equipment);

        $data = $request->validated();

        $equipment->update($data);

        $equipment->load([
            'user',
            'creator',
        ]);

        return $this->success(
            'Equipment updated successfully.',
            new EquipmentResource($equipment)
        );
    }

    // Remove the specified equipment from storage.
    public function destroy(Equipment $equipment)
    {
        $this->authorize('delete', $equipment);

        $equipment->delete();

        return $this->success(
            'Equipment deleted successfully.'
        );
    }

    // 3- إضافة/تعديل وصف (notes) للمعدة الخاصة بالمهندس أو القارئ بس (RU محدود)
    // حسب المستند: ما يقدر يغيّر باقي بيانات المعدة (الاسم، الحالة، ...) من هنا،
    // بس الوصف — والـ Policy تتأكد إنها معدته هو بالذات.
    public function describe(DescribeEquipmentRequest $request, Equipment $equipment)
    {
        $this->authorize('describe', $equipment);

        $equipment->update($request->validated());

        $equipment->load([
            'user',
            'creator',
        ]);

        return $this->success(
            'تم تحديث وصف المعدة بنجاح.',
            new EquipmentResource($equipment)
        );
    }

    // function with out route
    public function showByUser($userId)
    {
        $equipment = Equipment::with([
            'user',
            'creator',
        ])
            ->where('user_id', $userId)
            ->latest()
            ->get();

        return $this->success(
            'Equipment retrieved successfully.',
            EquipmentResource::collection($equipment)
        );
    }

    // ==========================================
    // دوال إضافية للتوافق مع مسارات الواجهة الثالثة للقارئ
    // ==========================================

    public function myEquipmentStats(Request $request)
    {
        return $this->myStats($request);
    }

    public function myEquipmentList(Request $request)
    {
        return $this->index($request);
    }
}
